# ThreadTracker

Every chart request first resolves its session to the current account, so callers
cannot act as someone else. Each gate below is an action that refuses with a code,
so a request that fails a gate is answered with an informative error rather than
left unanswered.

## Setting up a chart

A signed-in account [creates a chart](reaction:ThreadTracker.CreateChart) with a
title, the book's chapters as rows, and literary elements as columns, and becomes
its owner and first member. The owner
[adds a member by username](reaction:ThreadTracker.AddMember) when that username
is registered; [an unregistered username is refused](reaction:ThreadTracker.RejectUnknownMember)
with `UNKNOWN_USER`.

```endpoints
ThreadTracker.CreateChart at /charts/create
ThreadTracker.AddMember at /charts/add-member
ThreadTracker.RejectUnknownMember at /charts/add-member
```

A signed-in account [lists its charts](reaction:ThreadTracker.ListCharts), using
the [chart list](former:ThreadTracker.ChartList) of every chart it is a member of.

```endpoints
ThreadTracker.ListCharts at /charts/list
```

## Marking progress

A member [marks the last chapter they have read](reaction:ThreadTracker.UpdateProgress).
Charting locates that row's index, which becomes the member's progress in the chart,
so progress can never point past the last chapter.

```endpoints
ThreadTracker.UpdateProgress at /charts/progress
```

## Viewing the chart

A member [views the chart](reaction:ThreadTracker.ViewChart) through the
[chart view](former:ThreadTracker.ChartView). The chart view includes the chart's
title, its columns, and only the rows whose index is at most the member's progress.
For each visible row, it includes the posts placed there with their column, author,
quote, citation, analysis, upvote count, and whether the member has upvoted them,
and each post's comments, oldest first. Posts in rows the member has not reached are
never sent to the front end.

Filtering by literary element and exporting as a PDF both work on the chart view in
the front end, so they need no endpoints of their own and never reveal unread rows.

```endpoints
ThreadTracker.ViewChart at /charts/view
```

## Posting and commenting

A member [posts an idea](reaction:ThreadTracker.CreatePost) in a cell after
Charting confirms membership, locates the cell's row, and Progressing confirms the
member has reached that row. The new post is then placed in the cell.

A member [comments on a post](reaction:ThreadTracker.CreateComment) after Charting
locates the post's row and Progressing confirms the member has reached it. Comments
are not placed in the chart, so only top-level posts can be commented on.

The author of a post [deletes it](reaction:ThreadTracker.DeletePost). Posting
deletes the post with its comments, and Charting removes it from its cell.

```endpoints
ThreadTracker.CreatePost at /posts/create
ThreadTracker.CreateComment at /posts/comment
ThreadTracker.DeletePost at /posts/delete
```

## Upvoting

A member [upvotes a post](reaction:ThreadTracker.UpvotePost) after Charting locates
the post's row and Progressing confirms the member has reached it. Only top-level
posts can be upvoted.

```endpoints
ThreadTracker.UpvotePost at /posts/upvote
```
