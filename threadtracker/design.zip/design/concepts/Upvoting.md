# Upvoting

## Purpose

Let people signal the most valuable items, so the most valuable items stand out.

## Principle

Millie upvotes her classmate's post about Adam's name etymology, and its count goes
from 0 to 1. A second upvote by Millie is refused, so the count stays at 1. After
Millie removes her upvote, the count is 0 again, and removing it a second time is
refused.

## Types

```types
external User
  The person who upvotes an item.

external Item
  The thing being upvoted, such as a post.
```

## State

```state
a set of Upvotes with
  a voter User
  an item Item
  unique voter and item
```

## Actions

```actions
upvote(voter: User, item: Item) : returns ()
  where some upvote has voter and item
  then
    refuses ALREADY_UPVOTED "You have already upvoted this."
  where no upvote has voter and item
  then
    add a new upvote with voter and item
    returns

unvote(voter: User, item: Item) : returns ()
  where no upvote has voter and item
  then
    refuses NOT_UPVOTED "You have not upvoted this."
  where some upvote has voter and item
  then
    remove that upvote
    returns
```

## Queries

```queries
_count(item: Item) : one (count: Number)
  answers the number of upvotes with item
  answers 0 for an item with no upvotes

_hasUpvoted(voter: User, item: Item) : one (result: Flag)
  answers true when some upvote has voter and item
  answers false otherwise
```
