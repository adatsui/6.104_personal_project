# Charting

## Purpose

Organize items by where they are in an ordered sequence (rows) and by which category
they are in (columns), so items about one category can be read in sequence order.

## Principle

A teacher creates an *East of Eden* chart with the chapters as rows and "sibling
rivalry" and "Cain and Abel" as columns, and becomes its owner and first member. The
teacher adds Millie as a member. Millie places an item in the cell for Chapter 3 and
"sibling rivalry," and the items of the chart are listed in row order with their row
and column. Placing the same item a second time is refused, and so is placing an item
for someone who is not a member. After the item is removed, it is no longer listed.

## Types

```types
external User
  A person who owns a chart or is a member of it.

external Item
  The thing placed in a cell, such as a post.

opaque Labels
  An ordered list of label strings, such as the titles of a book's chapters.
```

## State

```state
a set of Charts with
  a title String
  an owner User

a seq of Rows with
  a chart Chart
  a label String

a seq of Columns with
  a chart Chart
  a label String
  unique chart and label

a set of Memberships with
  a chart Chart
  a member User
  unique chart and member

a seq of Placements with
  a unique item Item
  a chart Chart
  a row Row
  a column Column

Rule: the index of a row is its position among the rows of its chart, starting at 1
Rule: the row and column of a placement belong to the chart of that placement
```

## Actions

```actions
createChart(title: String, owner: User, rowLabels: Labels, columnLabels: Labels) : returns (chart: Chart)
  where title is blank
  then
    refuses BLANK_TITLE "A chart needs a title."
  where rowLabels is empty or some label in rowLabels or columnLabels is blank
  then
    refuses INVALID_LABELS "A chart needs at least one row, and every row and column needs a label."
  where columnLabels contains the same label twice
  then
    refuses DUPLICATE_COLUMN "This chart already has a column with that label."
  where title is not blank and the labels are accepted
  then
    add a new chart with title and owner
    add a new row with chart for each label in rowLabels, in order
    add a new column with chart for each label in columnLabels, in order
    add a new membership with chart and member owner
    returns chart

addMember(chart: Chart, owner: User, user: User) : returns ()
  where chart is not in Charts
  then
    refuses CHART_NOT_FOUND "There is no such chart."
  where owner is not the owner of chart
  then
    refuses NOT_OWNER "Only the owner of this chart can add members."
  where some membership has chart and member user
  then
    refuses ALREADY_MEMBER "That person is already a member of this chart."
  where owner is the owner of chart and no membership has chart and member user
  then
    add a new membership with chart and member user
    returns

addColumn(chart: Chart, label: String, user: User) : returns (column: Column)
  where chart is not in Charts
  then
    refuses CHART_NOT_FOUND "There is no such chart."
  where no membership has chart and member user
  then
    refuses NOT_MEMBER "You are not a member of this chart."
  where label is blank
  then
    refuses INVALID_LABELS "A chart needs at least one row, and every row and column needs a label."
  where some column of chart has label
  then
    refuses DUPLICATE_COLUMN "This chart already has a column with that label."
  where user is a member of chart and no column of chart has label
  then
    add a new column with chart and label after the other columns of chart
    returns column

addItem(item: Item, chart: Chart, row: Row, column: Column, user: User) : returns ()
  where chart is not in Charts
  then
    refuses CHART_NOT_FOUND "There is no such chart."
  where no membership has chart and member user
  then
    refuses NOT_MEMBER "You are not a member of this chart."
  where row or column does not belong to chart
  then
    refuses NOT_IN_CHART "That chapter or literary element is not in this chart."
  where some placement has item
  then
    refuses ALREADY_PLACED "That item is already in a cell."
  where user is a member of chart, row and column belong to chart, and item is not placed
  then
    add a new placement with item, chart, row, and column
    returns

deleteItem(item: Item, chart: Chart) : returns ()
  where no placement has item and chart
  then
    refuses ITEM_NOT_FOUND "That post is not in this chart."
  where some placement has item and chart
  then
    remove that placement
    returns

checkMember(chart: Chart, user: User) : returns ()
  where chart is not in Charts
  then
    refuses CHART_NOT_FOUND "There is no such chart."
  where no membership has chart and member user
  then
    refuses NOT_MEMBER "You are not a member of this chart."
  where some membership has chart and member user
  then
    returns

locateRow(row: Row, chart: Chart) : returns (index: Number)
  where row does not belong to chart
  then
    refuses NOT_IN_CHART "That chapter or literary element is not in this chart."
  where row belongs to chart
  then
    bind index to the index of row
    returns index

locateItem(item: Item, chart: Chart) : returns (row: Row, column: Column, index: Number)
  where no placement has item and chart
  then
    refuses ITEM_NOT_FOUND "That post is not in this chart."
  where some placement has item and chart
  then
    bind row and column to the row and column of that placement
    bind index to the index of that row
    returns row, column, index
```

## Queries

```queries
_get(chart: Chart) : optional (title: String, owner: User)
  answers the title and owner of chart
  answers no row for an unknown chart

_chartsFor(user: User) : many (chart: Chart, title: String, owner: User)
  answers every chart that user is a member of
  answers no rows when user is a member of no chart
  orders rows by when each chart was created

_rows(chart: Chart) : many (row: Row, label: String, index: Number)
  answers every row of chart with its label and index
  answers no rows for an unknown chart
  orders rows by index

_columns(chart: Chart) : many (column: Column, label: String)
  answers every column of chart with its label
  answers no rows for an unknown chart
  orders rows by when each column was added

_items(chart: Chart) : many (item: Item, row: Row, index: Number, column: Column)
  answers every placed item of chart with its row, the index of its row, and its column
  answers no rows for an unknown chart or a chart with no items
  orders rows by the index of their row, then by when each item was placed
```
